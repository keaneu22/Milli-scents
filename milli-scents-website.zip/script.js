const phone = "14434547347";

document.querySelectorAll(".select-btn").forEach((button) => {
  button.addEventListener("click", () => {
    const product = button.dataset.product || "";
    const price = button.dataset.price || "";
    const size = document.getElementById("size");
    if (product.includes("Travel")) size.value = "Travel Size — $10";
    else if (product.includes("Mix")) size.value = "Any Scent Mix 3.4ml — $40";
    else size.value = "3.4ml — $30";
    document.getElementById("scent").focus();
    document.getElementById("order").scrollIntoView({behavior:"smooth", block:"center"});
  });
});

document.getElementById("order").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const scent = document.getElementById("scent").value.trim();
  const size = document.getElementById("size").value;
  const details = document.getElementById("details").value.trim();

  const message =
`Hi Milli Scents! I'd like to place a fragrance request.

Name: ${name}
Scent/request: ${scent}
Option: ${size}
Details: ${details || "None"}

Please let me know the next steps.`;

  window.location.href = `sms:+${phone}?&body=${encodeURIComponent(message)}`;
});
