MILLI SCENTS WEBSITE
======================

Files:
- index.html
- styles.css
- script.js
- milli-scents-poster.jpg

How to use:
1. Upload all four files to your web host, keeping them in the same folder.
2. Open index.html as the site's home page.
3. The order form opens the customer's phone messaging app and prepares a text to 443-454-7347.

Notes:
- This is a front-end storefront. It does not process payments or store orders on a server.
- Add a payment provider and order-management backend when you are ready to take online checkout.
- The brand-name fragrance references are presented as scent inspiration; the site does not claim affiliation with those brands.
